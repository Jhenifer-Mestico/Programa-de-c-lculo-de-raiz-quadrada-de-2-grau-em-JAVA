/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package raizquad2grau;

/**
 *
 * @author Jhenifer
 */
import javax.swing.*;
import static java.lang.Math.sqrt;
public class Raizquad2Grau {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
       double  a, b, c;
   a = Double.parseDouble(
                 JOptionPane.showInputDialog (null, 
                 "Digite a: ", 
                 "Dado", JOptionPane.INFORMATION_MESSAGE) );
   b = Double.parseDouble(
                 JOptionPane.showInputDialog (null, 
                 "Digite b: ", 
                 "Dado", JOptionPane.INFORMATION_MESSAGE) );
   c = Double.parseDouble(
                 JOptionPane.showInputDialog (null, 
                 "Digite c: ", 
                 "Dado", JOptionPane.INFORMATION_MESSAGE) );
   if ( raizesReais(a,b,c) ) {
      JOptionPane.showMessageDialog (null, 
                 "O valor de X1 é " + getX1(a,b,c),
                 "X1", JOptionPane.INFORMATION_MESSAGE); 
      JOptionPane.showMessageDialog (null, 
                 "O valor de X2 é " + getX2(a,b,c),
                 "X2", JOptionPane.INFORMATION_MESSAGE); 
   } 
   else {
      JOptionPane.showMessageDialog (null, 
                 "Delta é negativo. Delta = " + getDelta(a,b,c),
                 "O valor de delta é negativo!", JOptionPane.INFORMATION_MESSAGE);    	
   }
}
   
static double getDelta (double a, double b, double c) {
  double d;
  d = b * b - 4 * a * c;
  return (d);
}

static double getX1 (double a, double b, double c) {
  return (  (-b + Math.sqrt(getDelta(a,b,c)) ) / (2*a) );
}

static double getX2 (double a, double b, double c) {
  return (  (-b - Math.sqrt(getDelta(a,b,c)) ) / (2*a) );
}

static boolean raizesReais (double a, double b, double c) {
  if ( getDelta(a,b,c) >= 0 ) return (true);  else return (false);
}

   
}

